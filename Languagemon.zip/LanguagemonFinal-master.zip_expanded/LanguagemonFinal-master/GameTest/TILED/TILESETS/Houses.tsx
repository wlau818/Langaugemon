<?xml version="1.0" encoding="UTF-8"?>
<tileset name="1698bf10a553033bdd5da6acde068ead" tilewidth="8" tileheight="8" tilecount="15488" columns="176">
 <image source="../IMAGES/1698bf10a553033bdd5da6acde068ead.png" trans="ff00ff" width="1408" height="704"/>
</tileset>
