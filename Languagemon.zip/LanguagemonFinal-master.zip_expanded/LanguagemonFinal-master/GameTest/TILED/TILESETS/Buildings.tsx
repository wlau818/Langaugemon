<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Buildings" tilewidth="8" tileheight="8" tilecount="11648" columns="104">
 <image source="../IMAGES/tileset-wesley.png" width="832" height="896"/>
</tileset>
