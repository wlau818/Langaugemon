

public class Instances {
	static int tile_X = 8, tile_Y = 8;
	
	public static Player player = new Player(tile_X, tile_Y);
	
	public static Background backgrounds = new Background();
	static String map = "C:\\Users\\winni\\OneDrive\\Pictures\\Screenshots\\town.png";
	
	//public static House house = new House();
	
}
