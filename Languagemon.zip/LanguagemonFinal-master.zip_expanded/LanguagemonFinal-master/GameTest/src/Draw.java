import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Draw extends Canvas {
	private JFrame frame = null;
	private Canvas canvas = null;
	private BufferedImage map = null;
	//private BufferedImage map2 = null;
	//private BufferedImage current = null;
	
	//private BufferedImage chara = null;

	BufferStrategy bufferStrategy;
	//private final int tile_X = 8, tile_Y = 8, tile_R = 100, tile_C = 100;
	//private final int tile_Total = tile_R * tile_C;
	//private final int map_Size = tile_X * tile_Y * tile_Total;
	
	private final int WIDTH = 480;
	private final int HEIGHT = 320;
	
	//private boolean change = false;
	
	private int num = 0;
	
	private House house = null;

	//Sets up the canvas.
	public Draw() {
		//Load the first map
		/*try {
			map = ImageIO.read(new File("C:\\Users\\winni\\OneDrive\\Pictures\\Screenshots\\town.png"));
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		try {
			map2 = ImageIO.read(new File("C:\\Users\\winni\\OneDrive\\Pictures\\Screenshots\\House.png"));
		} catch (IOException ex) {
			ex.printStackTrace();
		}*/
		Instances.player.setHouse(house);
		map = Instances.backgrounds.getImage(num);
		//house = new House();
		//current = map;
		//chara = Instances.player.getImage();
		// Makes a new window, with the name " Basic game ".
		frame = new JFrame("Basic Game");
		JPanel panel = (JPanel) frame.getContentPane();
		panel.setPreferredSize(new Dimension(map.getWidth() - 10, map.getHeight() - 10));
		panel.setSize(map.getWidth(), map.getHeight());
		panel.setLayout(null);

		canvas = new Canvas();
		canvas.setBounds(0, 0, map.getWidth(), map.getHeight());
		canvas.setIgnoreRepaint(true);
		canvas.setSize(map.getWidth(), map.getHeight());
		frame.setSize(map.getWidth(), map.getHeight());
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.pack();
		// this will make the frame not re-sizable
		frame.setResizable(false);
		frame.setVisible(true);
		// this will add the canvas to our frame
		panel.add(canvas);
		canvas.createBufferStrategy(2);
		bufferStrategy = canvas.getBufferStrategy();
		// This will make sure the canvas has focus, so that it can take input
		// from mouse/keyboard
		canvas.requestFocus();
		// this will set the background to black
		//canvas.setBackground(Color.black);
		// This will add our button handler to our program
		canvas.addKeyListener(new ButtonHandler());

	}

	/*@Override
	public Dimension getPreferredSize() {
		return (map == null) ? new Dimension(this.WIDTH, this.HEIGHT) : new Dimension(map.getWidth(), map.getHeight());
	}*/

	@Override
	
	// Draws the background
	public void paint(Graphics g) {
		super.paint(g);
		if (map != null) {
			
			g.drawImage(map, 0, 0, this);
			
			if (house != null) {
				g.drawImage(house.getImage(), house.getX(), house.getY(), this);
			}
		}
	}

	
	//Draws the image
	public void render() {
		Graphics2D g = (Graphics2D) bufferStrategy.getDrawGraphics();
		g.clearRect(0, 0, WIDTH, HEIGHT);
		paint(g);
		render(g);
		g.setColor(Color.MAGENTA);
		//g.drawString("Hello", 50, 50);
		g.dispose();
		bufferStrategy.show();
	}

	//Numbers corresponds with the backgrounds, and at each place the character has differet obstacles.
	//Pressing spaces is registered in the player class, integer returned to then change background.
	protected void render(Graphics2D g) {
		g.setColor(Color.pink);
		if (Instances.player.getInt() == 100) {
			map = Instances.backgrounds.getImage(1);
			num = 1;
		} else 
		if (Instances.player.getInt() == 200) {
			map = Instances.backgrounds.getImage(2);
			num = 2;
		} else 
		if (Instances.player.getInt() == 300) {
			map = Instances.backgrounds.getImage(3);
			num = 3;
		} else 
		if (Instances.player.getInt() == 400) {
			map = Instances.backgrounds.getImage(4);
			num = 4;
			
		} 
		
		if (num == 4 && Instances.player.getInt() >= 400) {
			if (Instances.player.getX() > 525) {
				
				g.drawImage(Instances.player.getImage(), 525, Instances.player.getY(), this);
				Instances.player.setX(525);
				
			} else if (Instances.player.getY() > map.getHeight() - Instances.player.getHeight()) {
				
				g.drawImage(Instances.player.getImage(), Instances.player.getX(), 
						map.getHeight() - Instances.player.getHeight(), this);
				
				Instances.player.setY(map.getHeight() - Instances.player.getHeight());
				
			} else if (Instances.player.getX() < 200) {
				
				g.drawImage(Instances.player.getImage(), 200, Instances.player.getY(), this);
				Instances.player.setX(200);
				
				
			} else if (Instances.player.getY() < 100) {
				
				g.drawImage(Instances.player.getImage(), Instances.player.getX(), 100, this);
				Instances.player.setY(100);
				
			} else if (Instances.player.getX() >= 320 && Instances.player.getX() <= 412
					&& Instances.player.getY() > 368) {
				num = 5;
				map = Instances.backgrounds.getImage(5);
				house = new House();
				Instances.player.setHouse(house);
				g.drawImage(Instances.player.getImage(), 440, 278, this);
				Instances.player.setX(440);
				Instances.player.setY(278);
			} else {
				g.drawImage(Instances.player.getImage(), Instances.player.getX(), Instances.player.getY(), this);
			}
		}
		
		if (num == 5) {
			if (Instances.player.getX() > 480) {
				
				g.drawImage(Instances.player.getImage(), 480, Instances.player.getY(), this);
				Instances.player.setX(480);
				
				
			} else if (Instances.player.getY() > 350) {
				
				g.drawImage(Instances.player.getImage(), Instances.player.getX(), 350, this);
				Instances.player.setY(350);
				
			} else if (Instances.player.getX() < 250) {
				
				g.drawImage(Instances.player.getImage(), 250, Instances.player.getY(), this);
				Instances.player.setX(250);
				
				
			} else if (Instances.player.getY() < 278) {
				
				g.drawImage(Instances.player.getImage(), Instances.player.getX(), 
						map.getHeight() - Instances.player.getHeight(), this);
				
				Instances.player.setY(map.getHeight() - Instances.player.getHeight());
				
			} else if (Instances.player.getX() >= 270 && Instances.player.getX() <= 336
					&& Instances.player.getY() > 340) {
				num = 6;
				map = Instances.backgrounds.getImage(6);
				String loc = "C:\\Users\\winni\\OneDrive\\Pictures\\Screenshots\\arena.png";
				house = null;
				house = new House(loc);
				Instances.player.setHouse(house);
				
				g.drawImage(Instances.player.getImage(), 680, 30, this);
				Instances.player.setX(680);
				Instances.player.setY(30);
			} else {
				g.drawImage(Instances.player.getImage(), Instances.player.getX(), Instances.player.getY(), this);
			}
		}
		
		if (num == 6) {
			if (Instances.player.getX() > map.getWidth() - Instances.player.getWidth()) {
				
				g.drawImage(Instances.player.getImage(), map.getWidth() - Instances.player.getWidth(), Instances.player.getY(), this);
				Instances.player.setX(map.getWidth() - Instances.player.getWidth());
				//change = true;
				//num = num + 1;
				
			} else if (Instances.player.getY() > 330) {
				
				g.drawImage(Instances.player.getImage(), Instances.player.getX(), 330, this);
				Instances.player.setY(330);
				
			} else if (Instances.player.getY() < 27) {
				
				g.drawImage(Instances.player.getImage(), Instances.player.getX(), 27, this);
				Instances.player.setY(27);
				
				
			} else if (Instances.player.getX() < 30) {
				
				g.drawImage(Instances.player.getImage(), 30, Instances.player.getY(), this);
				Instances.player.setX(30);
				
			} else if (Instances.player.getY() < 0) {
				
				g.drawImage(Instances.player.getImage(), Instances.player.getX(), map.getHeight() - Instances.player.getHeight(), this);
				Instances.player.setY(map.getHeight() - Instances.player.getHeight());
				
			} else if (Instances.player.getX() >= 114 && Instances.player.getX() <= 130
					&& Instances.player.getY() <= 235) {
				num = 7;
				map = Instances.backgrounds.getImage(7);
				house = null;
				Instances.player.setHouse(house);
				
				g.drawImage(Instances.player.getImage(), 360, 408, this);
				Instances.player.setX(360);
				Instances.player.setY(408);
			} else {
				g.drawImage(Instances.player.getImage(), Instances.player.getX(), Instances.player.getY(), this);
			}			
			//118, 226
			g.drawImage(Instances.player.getImage(), Instances.player.getX(), Instances.player.getY(), this);
			
		}
		
	if (num == 7) {
		if (Instances.player.getX() >= 400) {
			
			g.drawImage(Instances.player.getImage(), 400, Instances.player.getY(), this);
			Instances.player.setX(400);
			
			
		} else if (Instances.player.getY() > map.getHeight() - Instances.player.getHeight()) {
			
		/*	g.drawImage(Instances.player.getImage(), Instances.player.getX(), 
					map.getHeight() - Instances.player.getHeight(), this);
			Instances.player.setY(map.getHeight() - Instances.player.getHeight());
		*/	
			num = 6;
			map = Instances.backgrounds.getImage(6);
			String loc = "C:\\Users\\winni\\OneDrive\\Pictures\\Screenshots\\arena.png";
			house = null;
			house = new House(loc);
			Instances.player.setHouse(house);
			
			g.drawImage(Instances.player.getImage(), 120, 236, this);
			Instances.player.setX(120);
			Instances.player.setY(236);
			
		} else if (Instances.player.getY() < 127) {
				
			g.drawImage(Instances.player.getImage(), Instances.player.getX(), 127, this);
			Instances.player.setY(127);
			
				
		} else if (Instances.player.getX() <= 320) {
				
			g.drawImage(Instances.player.getImage(), 320, Instances.player.getY(), this);
			Instances.player.setX(320);
				
		} else if (Instances.player.getY() < 0) {
				
			g.drawImage(Instances.player.getImage(), Instances.player.getX(), map.getHeight() - Instances.player.getHeight(), this);
			Instances.player.setY(map.getHeight() - Instances.player.getHeight());				
		} else if (Instances.player.getX() >= 114 && Instances.player.getX() <= 130
				&& Instances.player.getY() == 226) {
			num = 7;
			map = Instances.backgrounds.getImage(7);
			house = null;
			Instances.player.setHouse(house);
			
			
			
		} else {
			g.drawImage(Instances.player.getImage(), Instances.player.getX(), Instances.player.getY(), this);
		}
		
		//System.out.println("Difference in Y:" + (map.getHeight() - 544));// x = 54 y = 65
		//g.fillRect(Instances.player.getX(), Instances.player.getY(), 15, 15);
		}
	}
	
	/*public Canvas getCanvas() {
		return canvas;
	}
	/*
	public int getHeight() {
		return map.getHeight() - 10;
	}
	
	
	
	
	if (Instances.player.getX() > map.getWidth() - Instances.player.getWidth()) {
				
				g.drawImage(Instances.player.getImage(), 0, Instances.player.getY(), this);
				Instances.player.setX(0);
				//change = true;
				//num = num + 1;
				
			} else if (Instances.player.getY() > map.getHeight() - Instances.player.getHeight()) {
				
				g.drawImage(Instances.player.getImage(), Instances.player.getX(), 0, this);
				Instances.player.setY(0);
				
			} else if (Instances.player.getX() < 0) {
				
				g.drawImage(Instances.player.getImage(), map.getWidth() - Instances.player.getWidth(), Instances.player.getY(), this);
				Instances.player.setX(map.getWidth() - Instances.player.getWidth());
				
				
			} else if (Instances.player.getY() < 0) {
				
				g.drawImage(Instances.player.getImage(), Instances.player.getX(), map.getHeight() - Instances.player.getHeight(), this);
				Instances.player.setY(map.getHeight() - Instances.player.getHeight());
				
			} else if (num == 1 && Instances.player.getX() >= 340 && Instances.player.getX() <= 392
					&& Instances.player.getY() > 368) {
				num = 2;
				house = new House();
				Instances.player.setHouse(house);
			} else {
				g.drawImage(Instances.player.getImage(), Instances.player.getX(), Instances.player.getY(), this);
			}
	
	
	
	public int getWidth() {
		return map.getWidth() - 10;
	} */
	
	
}