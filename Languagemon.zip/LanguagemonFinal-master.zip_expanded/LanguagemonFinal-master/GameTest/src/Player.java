import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Player{
	// variables which we will use
	private int x, y, tile_X, tile_Y;
	private boolean left = false, right = false, up = false, down = false, space = false;
	private int walk_speed = 300, run_speed = 100;
	
	private BufferedImage charaL;
	private BufferedImage charaR;
	private BufferedImage charaU;
	private BufferedImage charaD;
	
	private BufferedImage current;
	
	private int width, height;
	
	private int count = 0;
	
	private House house;

	
	// Sets the images and location of the player.
	public Player(int tile_X, int tile_Y) {
		this.tile_X = tile_X;
		this.tile_Y = tile_Y;
		
		String left = "C:\\Users\\winni\\OneDrive\\Pictures\\Screenshots\\girlL.png";
		String right = "C:\\Users\\winni\\OneDrive\\Pictures\\Screenshots\\girlR.png";
		String up = "C:\\Users\\winni\\OneDrive\\Pictures\\Screenshots\\girlU.png";
		String down = "C:\\Users\\winni\\OneDrive\\Pictures\\Screenshots\\girl.png";
		
		try {
	    	charaL = ImageIO.read(new File(left));
	    } catch (IOException e) {
	    	
	    }
		try {
	    	charaR = ImageIO.read(new File(right));
	    } catch (IOException e) {
	    	
	    }
		try {
	    	charaU = ImageIO.read(new File(up));
	    } catch (IOException e) {
	    	
	    }
		try {
	    	charaD = ImageIO.read(new File(down));
	    } catch (IOException e) {
	    	
	    }
		
		current = charaU;
		x = 288;
		y = 104;
		
		width = current.getWidth();
		height = current.getHeight();
	}

	// These 4 functions are able to set the direction
	public void setLeft(boolean left) {
		this.left = left;
	}

	public void setUp(boolean up) {
		this.up = up;
	}

	public void setDown(boolean down) {
		this.down = down;
	}

	public void setRight(boolean right) {
		this.right = right;
	}

	public void setRun(boolean space) {
		this.space = space;
		if (space) {
			count = count + 100;
		}
		
	}

	// This function will return X as an int.
	public int getX() {
		return x;
	}

	// And this function will return Y as an int.
	public int getY() {
		return y;
	}

	public void update() {
		move();
	}

	// This function will move the player according to its direction and speed
	public void move() {
		int sleep = (space) ? this.run_speed : this.walk_speed;
		if (left) {
			if (house != null) {
				if (!house.isOccupied(x - tile_X, y, width, height)) {
					x -= tile_X;
				}
			} else {
				x -= tile_X;
			}
			current = charaL;
		} else if (right) {
			if (house != null) {
				if (!house.isOccupied(x + tile_X, y, width, height)) {
					x += tile_X;
				}
			} else {
				x += tile_X;
			}
			
			current = charaR;
		} else if (up) {
			if (house != null) {
				if (!house.isOccupied(x, y - tile_Y, width, height)) {
					y -= tile_X;
				}
			} else {
				y -= tile_X;
			}
			current = charaU;
		} else if (down) {
			if (house != null) {
				if (!house.isOccupied(x, y + tile_Y, width, height)) {
					y += tile_X;
				}
			} else {
				y += tile_X;
			}
			current = charaD;
		}
		//System.out.println("x: " + x); //688
		//System.out.println("y: " + y); //544
		wait(sleep);
	}

	public void wait(int length) {
		long time = System.currentTimeMillis();
		long finish = time + length;
		while (true) {
			time = System.currentTimeMillis();
			if (time >= finish)
				break;
		}
	}
	
	//Current image to be drawn, changes as the character is moved.
	public BufferedImage getImage() {
		return current;
	}
	
	// Sets location
	public void setX(int newX) {
		x = newX;
	}
	
	public void setY(int newY) {
		y = newY;
	}
	
	// Gets size of image
	public int getHeight() {
		return height;
	}
	
	public int getWidth(){
		return width;
	}
	
	//Returns th amount of times space is pressed
	public int getInt() {
		return count;
	}
	
	//Gets the current house placed in map to it can be used to see where it can and cannot walk.
	public void setHouse(House h) {
		house = h;
	}
	
}