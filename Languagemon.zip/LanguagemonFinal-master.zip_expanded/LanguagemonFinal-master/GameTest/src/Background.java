import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Background {
	
	private BufferedImage[] background = new BufferedImage[10];
	
	
	//Stores information for the Draw class and then the images would be called to be drawn.
	public Background() {
		try {
			background[0] = ImageIO.read(new File("C:\\Users\\winni\\OneDrive\\Pictures\\Screenshots\\main.png"));
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		
		try {
			background[1] = ImageIO.read(new File("C:\\Users\\winni\\OneDrive\\Pictures\\Screenshots\\text1.png"));
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		
		try {
			background[2] = ImageIO.read(new File("C:\\Users\\winni\\OneDrive\\Pictures\\Screenshots\\text2.png"));
		} catch (IOException ex) {
			ex.printStackTrace();
		}

		try {
			background[3] = ImageIO.read(new File("C:\\Users\\winni\\OneDrive\\Pictures\\Screenshots\\text3.png"));
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		try {
			background[4] = ImageIO.read(new File("C:\\Users\\winni\\OneDrive\\Pictures\\Screenshots\\r.png"));
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		try {
			background[5] = ImageIO.read(new File("C:\\Users\\winni\\OneDrive\\Pictures\\Screenshots\\home.png"));
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		try {
			background[6] = ImageIO.read(new File("C:\\Users\\winni\\OneDrive\\Pictures\\Screenshots\\map2.png"));
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		
		try {
			background[7] = ImageIO.read(new File("C:\\Users\\winni\\OneDrive\\Pictures\\Screenshots\\room2.png"));
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		
	}
	
	//Returns the current image that is referred to.
	public BufferedImage getImage(int num) {
		return background[num];
	}

}
