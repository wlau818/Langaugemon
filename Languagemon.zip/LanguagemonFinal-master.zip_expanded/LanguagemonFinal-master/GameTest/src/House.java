import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class House {
	
	private BufferedImage house;
	
	private int width, height;
	private int x, y;
	
	//Stores information for the houses used.
	public House() {	//add parameters for location	
		try {
	    	house = ImageIO.read(new File("C:\\Users\\winni\\OneDrive\\Pictures\\Screenshots\\Lab.png"));
	    } catch (IOException e) {
	    	
	    }
		width = house.getWidth();
		height = house.getHeight();
		x = 200;
		y = 33;
	}
	
	public House(String loc) {
		try {
	    	house = ImageIO.read(new File(loc));
	    } catch (IOException e) {
	    	
	    }
		width = house.getWidth();
		height = house.getHeight();
		
		x = 60;
		y = 63;
	}
	
	public BufferedImage getImage() {
		return house;
	}
	
	// Prevents player from walking there 
	public boolean isOccupied(int px, int py, int pWidth, int pHeight) {
		if (px >= x - pWidth && px <= x + width
				&& py >= y - pHeight && py <= y + height - pHeight + 10) {
			return true;
		}
		return false;
	}
	
	//Gets location so it could be drawn in Draw class.
	public int getX() {
		return x;
	}
	
	public int getY() {
		return y;
	}
	
	

}
